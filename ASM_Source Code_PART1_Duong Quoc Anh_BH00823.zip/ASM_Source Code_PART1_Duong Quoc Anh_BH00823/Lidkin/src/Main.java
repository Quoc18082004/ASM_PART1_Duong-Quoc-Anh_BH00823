public class Main {
    class Node {
        int data;
        Node next;

        public Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    class LinkedListQueue {
        private Node front;
        private Node rear;

        public LinkedListQueue() {
            front = rear = null;
        }

        public void enqueue(int value) {
            Node newNode = new Node(value);
            if (rear == null) {
                front = rear = newNode;
                return;
            }
            rear.next = newNode;
            rear = newNode;
        }

        public int dequeue() {
            if (front == null) {
                System.out.println("Queue is empty");
                return -1; // Queue is empty
            }
            int value = front.data;
            front = front.next;
            if (front == null) {
                rear = null;
            }
            return value;
        }
    }

    public static void main(String[] args) {
        Main main = new Main();
        LinkedListQueue queue = main.new LinkedListQueue();

        queue.enqueue(10);
        queue.enqueue(20);
        queue.enqueue(30);

        System.out.println(queue.dequeue()); // 10
        System.out.println(queue.dequeue()); // 20
        System.out.println(queue.dequeue()); // 30
        System.out.println(queue.dequeue()); // -1 (Queue is empty)
    }
}