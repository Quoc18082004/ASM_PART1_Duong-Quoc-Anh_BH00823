// TIP: To Run code, press <shortcut actionId="Run"/>
// or click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.

import java.util.ArrayList;  // Import outside the class

public class Main {

    // Define a generic Stack class
    public static class Stack<T> {
        private ArrayList<T> stack;  // Internal list to store elements

        // Constructor to initialize the stack
        public Stack() {
            stack = new ArrayList<>();
        }

        // Push operation: Add an element to the top
        public void push(T element) {
            stack.add(element);
            System.out.println(element + " has been pushed onto the stack.");
        }

        // Pop operation: Remove and return the top element
        public T pop() {
            if (isEmpty()) {
                System.out.println("Stack is empty! Cannot pop.");
                return null;
            }
            T topElement = stack.remove(stack.size() - 1);
            System.out.println(topElement + " has been popped from the stack.");
            return topElement;
        }

        // Peek operation: View the top element without removing it
        public T peek() {
            if (isEmpty()) {
                System.out.println("Stack is empty! Nothing to peek.");
                return null;
            }
            return stack.get(stack.size() - 1);
        }

        // Check if the stack is empty
        public boolean isEmpty() {
            return stack.isEmpty();
        }
    }

    // Main method to test stack operations
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();

        // Push elements onto the stack
        stack.push(10);
        stack.push(20);
        stack.push(30);

        // Peek the top element
        System.out.println("Top element: " + stack.peek());

        // Pop elements from the stack
        stack.pop();
        stack.pop();

        // Check if the stack is empty
        System.out.println("Is the stack empty? " + stack.isEmpty());

        // Pop the remaining element
        stack.pop();
        System.out.println("Is the stack empty? " + stack.isEmpty());
    }
}
